/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package FormAdmin;

/**
 *
 * @author asus
 */
public class FormAdmin {

    public static void main() {
        FormHomeAdmin formHomeAdmin = new FormHomeAdmin();
        formHomeAdmin.setVisible(true);
    }
}
