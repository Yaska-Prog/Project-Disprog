/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package FormRegistrasiAccount;

/**
 *
 * @author ardel
 */
public class FormRegistrasiAccount {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        FormAwal formAwal = new FormAwal();
        formAwal.setVisible(true);
    }

}
